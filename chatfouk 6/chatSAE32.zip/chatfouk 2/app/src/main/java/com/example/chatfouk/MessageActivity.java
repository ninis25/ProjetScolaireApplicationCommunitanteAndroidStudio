package com.example.chatfouk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.chatfouk.R;


public class MessageActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message_activity);

        Button btnLogin = findViewById(R.id.);
        Button btnSignUp = findViewById(R.id.);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(MessageActivity.this,messageITEM.class);
                startActivity(loginIntent);
            }
        });



    }
}
