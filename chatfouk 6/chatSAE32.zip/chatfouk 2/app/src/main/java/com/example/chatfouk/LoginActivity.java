package com.example.chatfouk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.chatfouk.R;


public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editTextUsername = findViewById(R.id.editTextLoginUsername);
                EditText editTextPassword = findViewById(R.id.editTextLoginPassword);

                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                // Valider les entrées et se connecter
                //if (validateLogin(username, password)) {
                    //loginUser(username, password);
                    Intent intent = new Intent(LoginActivity.this, MessageActivity.class);
                    //startActivity(intent);
                    //finish();
                }
            });

    }

    private void loginUser(String username, String password) {

    }

    private boolean validateLogin(String username, String password) {
        // Logique pour valider les entrées
        // Retournez 'true' si les entrées sont valides, sinon 'false'
        return true; // Vous devez implémenter cette logique selon vos critères de validation
    }
}