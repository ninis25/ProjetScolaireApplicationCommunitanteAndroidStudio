package com.example.chatfouk;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class messageITEM extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message_item);
    }


}
