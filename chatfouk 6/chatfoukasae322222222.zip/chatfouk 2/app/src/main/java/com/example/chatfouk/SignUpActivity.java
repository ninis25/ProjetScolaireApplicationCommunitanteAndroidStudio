package com.example.chatfouk;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_activity);

        Button buttonRegister = findViewById(R.id.buttonRegister);
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editTextUsername = findViewById(R.id.editTextUsername);
                EditText editTextPassword = findViewById(R.id.editTextPassword);

                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (validateRegistration(username, password)) {
                    new RegistrationTask().execute(username, password);
                }
            }
        });
    }

    private class RegistrationTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String username = params[0];
            String password = params[1];

            try (DatagramSocket socket = new DatagramSocket()) {
                InetAddress address = InetAddress.getByName("127.0.0.1"); // Remplacez par l'adresse IP de votre serveur
                String message = "creation " + username + " " + password;
                byte[] buf = message.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 6012);
                socket.send(packet);

                // Attendre la réponse du serveur
                buf = new byte[1024];
                packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                String response = new String(packet.getData(), 0, packet.getLength());
                return response.contains("inscription réussie");
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(SignUpActivity.this, "Registration successful.", Toast.LENGTH_SHORT).show();
                // Vous pouvez également rediriger l'utilisateur vers la page de connexion ou une autre activité ici
            } else {
                Toast.makeText(SignUpActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean validateRegistration(String username, String password) {
        // Ajoutez ici votre logique de validation
        // Par exemple, vérifiez si les champs ne sont pas vides, si le mot de passe a une longueur minimale, etc.
        return !username.isEmpty() && !password.isEmpty();
    }
}


