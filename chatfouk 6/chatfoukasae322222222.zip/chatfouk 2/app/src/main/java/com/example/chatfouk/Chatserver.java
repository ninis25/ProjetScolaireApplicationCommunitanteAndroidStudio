package com.example.chatfouk;
import android.os.Message;

import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer implements  Runnable {
    public final static int PORT = 6012;
    private final static int BUFFER = 1024;
    private final static int MAX_USERS = 100;

    private DatagramSocket socket;
    private ArrayList<InetAddress> client_addresses;
    private ArrayList<Integer> client_ports;
    private HashSet<String> existing_clients;
    private ArrayList<Utilisateur> listOfUsers;

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public ChatServer() throws IOException {
        socket = new DatagramSocket(PORT);
        System.out.println("Le serveur est hébergé sur le port : " + PORT);
        client_addresses = new ArrayList();
        client_ports = new ArrayList();
        existing_clients = new HashSet();
        listOfUsers = new ArrayList();
    }

//	private String getUserName(InetAddress clientAddress, int clientPort) {
//		for (Utilisateur utilisateur : listOfUsers) {
//			if (utilisateur.getIpAddress().equals(clientAddress)) {
//				return utilisateur.getLogin();
//			}
//		}
//		return "127.0.0.1"; // Remplacer par une valeur par défaut ou traiter comme nécessaire
//	}

    public String getUserByMail(String mail) {
        for (Utilisateur utilisateur : listOfUsers) {
            if (utilisateur.getEmail().equals(mail)) {
                return utilisateur.getEmail();
            }
        }
        return "None";
    }

    public Utilisateur returnUser(String mail) throws UnknownHostException {
        for (Utilisateur utilisateur : listOfUsers) {
            if (utilisateur.getEmail().equals(mail)) {
                return utilisateur;
            }
        }
        // Si l'utilisateur n'est pas trouvé, retourne un utilisateur introuvable
        return new Utilisateur("UtilisateurIntrouvable", "server", "@unknown",InetAddress.getByName("127.0.0.1"), 6012);

    }

    public void sendMessage(String message, InetAddress clientAddress, int clientPort) {
        try {
            byte[] data = message.getBytes();
            DatagramPacket packet = new DatagramPacket(data, data.length, clientAddress, clientPort);
            socket.send(packet);
        } catch (IOException e) {
            System.err.println("Erreur lors de l'envoi du message au client : " + e.getMessage());
        }
    }

    public void creation(DatagramPacket packet, String message) {
        String[] parts = message.split(" ");
        System.out.println("Parts du message : " + Arrays.toString(parts));
        System.out.println("Liste user : " + listOfUsers +"\n");
        String login = parts[1];
        String password = parts[2];
        String email = parts[3];

        // Vérifier si l'utilisateur existe déjà
        boolean exists = listOfUsers.stream().anyMatch(user -> user.getLogin().equals(login));

        if (!exists) {
            // Ajouter l'utilisateur à la liste
            listOfUsers.add(new Utilisateur(login, password, email, packet.getAddress(), packet.getPort()));

            // Message de confirmation pour le client
            String confirmationMessage = login + " , l'inscription est réussie !";
            sendMessage(confirmationMessage, packet.getAddress(), packet.getPort());

            System.out.println("User created");
        } else {
            System.out.println("Erreur, votre identifiant est déjà utilisé");
            // Envoyer un message d'erreur au client si l'utilisateur existe déjà
            String errorMessage = "Erreur, votre identifiant est déjà utilisé";
            sendMessage(errorMessage, packet.getAddress(), packet.getPort());
        }
//		Utilisateur user = new Utilisateur(login, password, packet.getAddress(), packet.getPort());
//		listOfUsers.add(user);
//		System.out.println("User created");
    }

    public void connexion(DatagramPacket packet, String message) {
        String[] parts = message.split(" ");
        boolean userExists = false;

        for (Utilisateur utilisateur : listOfUsers) {
            if (utilisateur.getLogin().equals(parts[1])) {
                System.out.println(utilisateur.getLogin());
                userExists = true;
                System.out.println("User already exists");
                System.out.println("User status : " + utilisateur.estConnecte());
                System.out.println("User password : " + utilisateur.getPwd());
                if (utilisateur.getPwd().equals(parts[2]) && !utilisateur.estConnecte()) {
                    utilisateur.connecte();
                    System.out.println("Connexion réussie : " + parts[1]);
                    sendMessage("Connexion réussie : " + utilisateur.getLogin(), packet.getAddress(), packet.getPort());
                    return;
                } else {
                    System.out.println("Connection refused");
                    sendMessage("Connexion refusée", packet.getAddress(), packet.getPort());
                }
            }
        }
    }

    public void lecture(DatagramPacket packet, String message) throws UnknownHostException {
        String[] parts = message.split(" ");
        boolean userExists = false;
        System.out.println(getUserByMail(parts[1]));
        System.out.println(getUserByMail(parts[2]));

        if (!parts[1].equals("None") && !parts[2].equals("None")) {
            System.out.println(parts[3] + " " + parts[4]);
            System.out.println("testststs"); // STOP PAUSE

            // Si c'est le cas, on récupère les objets utilisateurs correspondants
            Utilisateur user1 = returnUser(parts[1]);
            Utilisateur user2 = returnUser(parts[2]);

            // On vérifie les différentes contraintes qui empêchent l'envoi d'un message
            // Si les utilisateurs sont amis et s'ils existent bien dans la base de données,
            // on envoie le message qui sera stocké dans les listes des messages des deux utilisateurs
            if (user1.isFriendWith(user2) && !user1.getEmail().equals("UtilisateurIntrouvable") && !user2.getEmail().equals("UtilisateurIntrouvable")) {
                Message messageObject = new Message(user1,parts[3], user2);
                System.out.println(message);
                messageObject.Ecrire_Message(parts[3], parts[4]);
                user1.setMessage(messageObject);
                user2.setMessage(messageObject);
                System.out.println(user1.getMessageList());

                String msg2 = "Client : votre message a bien été envoyé";
                System.out.println(msg2);
                sendMessage(msg2, packet.getAddress(), packet.getPort());
            } else {
                String msg2 = "Le message ne peut être envoyé car " + parts[1] + " ou " + parts[2] + " n'existent pas";
                sendMessage(msg2, packet.getAddress(), packet.getPort());
            }
        } else {
            String msg2 = "Le message ne peut être envoyé car les utilisateurs renseignés ne sont pas corrects";
            sendMessage(msg2, packet.getAddress(), packet.getPort());
        }
    }


    public void whoIsConnected() {
        for (Utilisateur utilisateur : listOfUsers) {
            if (utilisateur.estConnecte()) {
                System.out.println(utilisateur.getLogin());
            }
        }
    }

    public void deconnexion(String message) {
        String[] parts = message.split(" ");
        String login = parts[1];
        for (Utilisateur utilisateur : listOfUsers) {
            if (utilisateur.getLogin().equals(login)) {
                utilisateur.deconnecte();
                System.out.println("Utilisateur déconnecté : " + login);
            }
        }
    }

    private void demandeAmi(DatagramPacket packet, String message) throws IOException {
        String[] parts = message.split(" ");

        if (parts.length == 3) {
            String emailDemandeur = parts[1];
            Utilisateur utilisateurCourant = returnUser(emailDemandeur);

            String emailDemande = parts[2];
            Utilisateur demandeur = returnUser(emailDemande);

            if (demandeur != null) {
                // Supposons que "utilisateurCourant" soit l'utilisateur actuellement connecté
                utilisateurCourant.envoyerDemandeAmi(demandeur);


                // Envoyez une confirmation au demandeur
                String confirmationMessage = "Demande d'ami envoyée à : " + emailDemande;
                sendMessage(confirmationMessage, packet.getAddress(), packet.getPort());
            } else {
                // Envoyez un message d'erreur si l'utilisateur demandeur n'existe pas
                String errorMessage = "L'utilisateur demandeur n'existe pas.";
                sendMessage(errorMessage, packet.getAddress(), packet.getPort());
            }
        } else {
            // Envoyez un message d'erreur si le format du message est invalide
            String errorMessage = "Format de message invalide pour demande_ami.";
            sendMessage(errorMessage, packet.getAddress(), packet.getPort());
        }
    }
    private void accepteAmi(DatagramPacket packet, String message) throws IOException {
        String[] parts = message.split(" ");

        if (parts.length == 2) {
            String emailDemande = parts[1];
            Utilisateur demandeur = returnUser(emailDemande);

            // Supposons que "utilisateurCourant" soit l'utilisateur actuellement connecté
            Utilisateur utilisateurCourant = /* obtenir l'utilisateur courant */;

            if (demandeur != null && utilisateurCourant != null) {
                // Ajoutez demandeur à la liste d'amis de utilisateurCourant
                utilisateurCourant.setAmis(demandeur, true);

                // Supprimez la demande d'ami de la liste d'attente de utilisateurCourant
                utilisateurCourant.getAttente().remove(demandeur);

                // Envoyez un message de confirmation au demandeur
                String confirmationMessage = "Demande d'ami acceptée par : " + utilisateurCourant.getEmail();
                sendMessage(confirmationMessage, packet.getAddress(), packet.getPort());
            } else {
                // Envoyez un message d'erreur si l'utilisateur demandeur n'existe pas
                String errorMessage = "L'utilisateur demandeur n'existe pas.";
                sendMessage(errorMessage, packet.getAddress(), packet.getPort());
            }
        } else {
            // Envoyez un message d'erreur si le format du message est invalide
            String errorMessage = "Format de message invalide pour accepte_ami.";
            sendMessage(errorMessage, packet.getAddress(), packet.getPort());
        }
    }


    public void viewUsers() {
        for (Utilisateur utilisateur : listOfUsers) {
            // Print all users information
            System.out.println(utilisateur.toString());
        }
    }



    public void run() {
        byte[] buffer = new byte[BUFFER];
        while (true) {
            try {
                Arrays.fill(buffer, (byte) 0);
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);

                String message = new String(buffer, 0, packet.getLength());

                InetAddress clientAddress = packet.getAddress();
                int client_port = packet.getPort();

                String id = clientAddress.toString() + "|" + client_port;

                // Check if the maximum limit is reached
                if (client_addresses.size() >= MAX_USERS) {
                    System.out.println("Maximum user limit reached. Connection from " + id + " rejected.");
                    continue; // Skip processing further for this client
                }

                if (!existing_clients.contains(id)) {
                    existing_clients.add(id);
                    client_ports.add(client_port);
                    client_addresses.add(clientAddress);
//					// Assuming you have a method to get a username based on InetAddress
//					String userName = getUserName(clientAddress, packet.getPort());
//					Utilisateur user = new Utilisateur(userName, "password", clientAddress);
//					listOfUsers.add(user);
                }

                String msg = null;
                if (message.contains("creation")) {
                    creation(packet, message);
                } else if (message.contains("connexion")) {
                    connexion(packet, message); // Supprimer les premiers 5 caractères
                    continue;
                } else if (message.contains("logout")) {
                    deconnexion(message);
                } else if (message.contains("view")) {
                    viewUsers();
                } else if (message.contains("who")) {
                    whoIsConnected();
                } else if (message.contains("lecture")) {
                    lecture(packet, message);
                } else if (message.contains("demande_ami")) {
                    demandeAmi(packet,message);
                } else if (message.contains("accepte_ami")) {
                    accepteAmi(packet,message);
                } else {
                    msg = id + " : " + message;
                }

                System.out.println(id + " : " + message);

                byte[] data = (id + " : " + message).getBytes();
                for (int i = 0; i < client_addresses.size(); i++) {
                    InetAddress cl_address = client_addresses.get(i);
                    int cl_port = client_ports.get(i);
                    packet = new DatagramPacket(data, data.length, cl_address, cl_port);
                    socket.send(packet);
                }

            } catch (Exception e) {
                System.err.println(e);
            }
        }
    }


    public static void main(String args[]) throws Exception {
        ChatServer server_thread = new ChatServer();
        Utilisateur user1 = new Utilisateur("john", "password1", "john@sae", InetAddress.getByName("127.0.0.1"), 6012);
        Utilisateur user2 = new Utilisateur("alice", "password2", "alice@sae",InetAddress.getByName("127.0.0.1"), 6012);
        server_thread.listOfUsers.add(user1);
        server_thread.listOfUsers.add(user2);
        server_thread.run();

        Thread thread = new Thread(server_thread);
        thread.start();
    }
}


}
