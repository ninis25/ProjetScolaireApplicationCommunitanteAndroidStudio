import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

class MessageSender implements Runnable {
	public final static int PORT = 6012;
	private final DatagramSocket socket;
	private final String hostName;
	private final ClientWindow window;

	MessageSender(DatagramSocket sock, String host, ClientWindow win) {
		socket = sock;
		hostName = host;
		window = win;
	}

	private void sendMessage(String s) throws Exception {
		byte buffer[] = s.getBytes();
		InetAddress address = InetAddress.getByName(hostName);
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, PORT);
		socket.send(packet);
	}


	public void run() {
		boolean connected = false;
		do {
			try {
				sendMessage("New client connected - welcome!");
				connected = true;
			} catch (Exception e) {
				window.displayMessage(e.getMessage());
			}
		} while (!connected);
		while (true) {
			try {
				while (!window.message_is_ready) {
					Thread.sleep(100);
				}
				sendMessage(window.getMessage());
				window.setMessageReady(false);
			} catch (Exception e) {
				window.displayMessage(e.getMessage());
			}
		}
	}
}

class MessageReceiver implements Runnable {
	DatagramSocket socket;
	byte buffer[];
	ClientWindow window;

	MessageReceiver(DatagramSocket sock, ClientWindow win) {
		socket = sock;
		buffer = new byte[1024];
		window = win;
	}

	public void run() {
		while (true) {
			try {
				DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
				socket.receive(packet);
				String received = new String(packet.getData(), 0, packet.getLength()).trim();
				System.out.println(received);
				window.displayMessage(received);
			} catch (Exception e)
		{
				System.err.println(e);
			}
		}
	}

}


public class ChatClient {

	public static void main(String args[]) throws Exception {
		ClientWindow window = new ClientWindow();
		String host = window.getHostName();

		window.setTitle("UDP Server Chat: " + host);
		DatagramSocket socket = new DatagramSocket();
		MessageReceiver receiver = new MessageReceiver(socket, window);
		MessageSender sender = new MessageSender(socket, host, window);
		Thread receiverThread = new Thread(receiver);
		Thread senderThread = new Thread(sender);
		receiverThread.start();
		senderThread.start();
	}
}